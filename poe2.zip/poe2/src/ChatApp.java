import javax.swing.JOptionPane;
import java.io.FileWriter;
import java.io.IOException;

public class ChatApp {
    
    static String storedUsername;
    static String storedPassword;
    static String storedCell;
    static int messageCount = 0;

    public static void main(String[] args) {
        storedUsername = JOptionPane.showInputDialog("Enter username:");
        while (!checkUserName(storedUsername)) {
            storedUsername = JOptionPane.showInputDialog("Username is not correctly formatted. Try again:");
        }

        storedPassword = JOptionPane.showInputDialog("Enter password:");
        while (!checkPasswordComplexity(storedPassword)) {
            storedPassword = JOptionPane.showInputDialog("Password is not correctly formatted. Try again:");
        }

        storedCell = JOptionPane.showInputDialog("Enter cell phone number:");
        while (!checkCellPhoneNumber(storedCell)) {
            storedCell = JOptionPane.showInputDialog("Cell number incorrectly formatted. Try again:");
        }

        JOptionPane.showMessageDialog(null, "Registration successful.");

        String loginUser = JOptionPane.showInputDialog("Enter username to login:");
        String loginPass = JOptionPane.showInputDialog("Enter password to login:");

        if (!loginUser(loginUser, loginPass)) {
            JOptionPane.showMessageDialog(null, "Username or password incorrect.");
            return;
        }

        JOptionPane.showMessageDialog(null, "Welcome back!");

        int totalMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to enter?"));
        int sentCount = 0;

        while (true) {
            String option = JOptionPane.showInputDialog("1. Send Message\n2. Show recently sent messages\n3. Quit");
            if (option == null) break;
            int choice = Integer.parseInt(option);

            switch (choice) {
                case 1:
                    if (sentCount >= totalMessages) {
                        JOptionPane.showMessageDialog(null, "Message limit reached.");
                        break;
                    }

                    String recipient = JOptionPane.showInputDialog("Enter recipient number:");
                    if (!checkCellPhoneNumber(recipient)) {
                        JOptionPane.showMessageDialog(null, "Invalid cell number.");
                        break;
                    }

                    String message = JOptionPane.showInputDialog("Enter message (max 250 characters):");
                    if (message.length() > 250) {
                        JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by " + (message.length() - 250));
                        break;
                    }

                    String messageId = generateMessageId();
                    String hash = createMessageHash(messageId, messageCount + 1, message);

                    String action = JOptionPane.showInputDialog("Send / Store / Discard");

                    switch (action.toLowerCase()) {
                        case "send":
                            JOptionPane.showMessageDialog(null, "Message successfully sent.");
                            break;
                        case "store":
                            storeMessage(messageId, recipient, message, hash);
                            JOptionPane.showMessageDialog(null, "Message successfully stored.");
                            break;
                        case "discard":
                            JOptionPane.showMessageDialog(null, "Press 0 to delete message.");
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Invalid option.");
                            continue;
                    }

                    JOptionPane.showMessageDialog(null,
                            "Message ID: " + messageId +
                            "\nMessage Hash: " + hash +
                            "\nRecipient: " + recipient +
                            "\nMessage: " + message);
                    
                    messageCount++;
                    sentCount++;
                    break;

                case 2:
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                    break;

                case 3:
                    JOptionPane.showMessageDialog(null, "Goodbye.");
                    return;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid selection.");
            }
        }
    }

    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        return password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+=<>?]).{8,}$");
    }

    public static boolean checkCellPhoneNumber(String number) {
        return number.matches("^\\+\\d{10,13}$");
    }

    public static boolean loginUser(String username, String password) {
        return storedUsername.equals(username) && storedPassword.equals(password);
    }

    public static String generateMessageId() {
        long num = (long) (Math.random() * 1_000_000_0000L);
        return String.format("%010d", num);
    }

    public static String createMessageHash(String id, int count, String message) {
        String[] words = message.trim().split("\\s+");
        String first = words.length > 0 ? words[0].toUpperCase() : "";
        String last = words.length > 1 ? words[words.length - 1].toUpperCase() : "";
        return id.substring(0, 2) + ":" + count + ":" + first + last;
    }

    public static void storeMessage(String id, String recipient, String message, String hash) {
        JSONObject obj = new JSONObject();
        obj.put("messageId", id);
        obj.put("messageNumber", messageCount + 1);
        obj.put("recipient", recipient);
        obj.put("messageText", message);
        obj.put("messageHash", hash);

        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(obj.toJSONString() + System.lineSeparator());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

